from .server import HTTPServer, add_route, check


__version__ = "0.1.0"
__author__ = "Marwynn Somridhivej"
__license__ = "MIT"
